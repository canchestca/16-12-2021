package vn.hust.edu.listexamples;

public interface ItemClickListener {
    void onItemClick(ItemModel item);
}
