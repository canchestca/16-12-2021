package vn.hust.edu.listexamples;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {

    List<ItemModel> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        items = new ArrayList<>();
        for (int i = 1; i <= 20; i++)
            items.add(new ItemModel("Item " + i,
                    getResources().getIdentifier("thumb" + i, "drawable", getPackageName())));


        ItemAdapter adapter = new ItemAdapter(items);
        ListView listView = findViewById(R.id.list_view);
        listView.setAdapter(adapter);

    }
}