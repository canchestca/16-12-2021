package vn.hust.edu.listexamples;

public class ItemModel {
    private String title;
    private int imageResource;
    private int imageLargeResource;
    private boolean selected;

    public ItemModel(String title, int imageResource) {
        this.title = title;
        this.imageResource = imageResource;
        this.selected = false;
    }

    public ItemModel(String title, int imageResource, int imageLargeResource) {
        this.title = title;
        this.imageResource = imageResource;
        this.imageLargeResource = imageLargeResource;
        this.selected = false;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public boolean isSelected() {
        return selected;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImageResource() {
        return imageResource;
    }

    public void setImageResource(int imageResource) {
        this.imageResource = imageResource;
    }

    public int getImageLargeResource() {
        return imageLargeResource;
    }
}
