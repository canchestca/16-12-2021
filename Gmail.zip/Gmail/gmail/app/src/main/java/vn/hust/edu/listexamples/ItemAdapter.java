package vn.hust.edu.listexamples;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ItemAdapter extends BaseAdapter {

    List<ItemModel> items;

    public ItemAdapter(List<ItemModel> items) {
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        MyViewHolder viewHolder;

        if (view == null) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.custom_item_layout_3, null);

            viewHolder = new MyViewHolder();
            viewHolder.imageAvatar = view.findViewById(R.id.image_avatar);
            viewHolder.textTitle = view.findViewById(R.id.text_title);
            viewHolder.imageDelete = view.findViewById(R.id.image_delete);
            viewHolder.checkSelected = view.findViewById(R.id.check_select);

            view.setTag(viewHolder);
        } else
            viewHolder = (MyViewHolder) view.getTag();

        ItemModel item = items.get(i);

        viewHolder.imageAvatar.setImageResource(item.getImageResource());
        viewHolder.textTitle.setText(item.getTitle());

        viewHolder.imageDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                items.remove(i);
                notifyDataSetChanged();
            }
        });

        viewHolder.checkSelected.setChecked(item.isSelected());

        viewHolder.checkSelected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                item.setSelected(!item.isSelected());
                notifyDataSetChanged();
            }
        });

        return view;
    }

    class MyViewHolder {
        ImageView imageAvatar;
        TextView textTitle;
        ImageView imageDelete;
        CheckBox checkSelected;
    }
}
