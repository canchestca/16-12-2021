package vn.hust.edu.listexamples;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ItemAdapter2 extends RecyclerView.Adapter<ItemAdapter2.ItemViewHolder> {

    List<ItemModel> items;
    ItemClickListener listener;

    public ItemAdapter2(List<ItemModel> items, ItemClickListener listener) {
        this.listener = listener;
        this.items = items;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_item_layout_3, parent, false);
        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        ItemModel item = items.get(position);
        holder.imageAvatar.setImageResource(item.getImageResource());
        holder.textTitle.setText(item.getTitle());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class ItemViewHolder extends RecyclerView.ViewHolder {

        ImageView imageAvatar;
        TextView textTitle;
        ImageView imageDelete;
        CheckBox checkBox;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            this.imageAvatar = itemView.findViewById(R.id.image_avatar);
            this.textTitle = itemView.findViewById(R.id.text_title);
            this.imageDelete = itemView.findViewById(R.id.image_delete);
            this.checkBox = itemView.findViewById(R.id.check_select);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ItemModel item = items.get(getAdapterPosition());
                    listener.onItemClick(item);
                }
            });
        }
    }
}
