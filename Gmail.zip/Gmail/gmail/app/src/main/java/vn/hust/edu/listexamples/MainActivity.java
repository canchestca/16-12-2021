package vn.hust.edu.listexamples;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<String> items;
    ArrayAdapter<String> adapter;

    String[] words = { "words", "starting", "with", "set", "Setback",
            "Setline", "Setoffs", "Setouts", "Setters", "Setting",
            "Settled", "Settler", "Wordless", "Wordiness", "Adios" };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        items = new ArrayList<>();
        for (int i = 0; i < 50; i++)
            items.add("Item " + i);

        // adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);

        // adapter = new ArrayAdapter<>(this, R.layout.custom_item_layout, R.id.text_title, items);

//        ListView listContacts = findViewById(R.id.list_contacts);
//        listContacts.setAdapter(adapter);
//
//        listContacts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                String item = items.get(i);
//                Log.v("TAG", item + " is selected");
//            }
//        });

//        Spinner spinner = findViewById(R.id.spinner1);
//        spinner.setAdapter(adapter);
//        spinner.setSelection(10);

//        GridView gridView = findViewById(R.id.gridview1);
//        gridView.setAdapter(adapter);
//        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                String item = items.get(i);
//                Log.v("TAG", item + " is selected");
//            }
//        });

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, words);
        AutoCompleteTextView autoEdit = findViewById(R.id.auto_edit);
        autoEdit.setAdapter(adapter);

        findViewById(R.id.button_add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                items.add(0, "Added Item");
                adapter.notifyDataSetChanged();
            }
        });

        findViewById(R.id.button_remove).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                items.remove(0);
                adapter.notifyDataSetChanged();
            }
        });

        findViewById(R.id.button_update).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                items.set(0, "Updated item");
                adapter.notifyDataSetChanged();
            }
        });
    }

}